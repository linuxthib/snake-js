/*author : thibaut lemaire
/*date de création : 2017
/*date de modification : 18/12/2019*/

$(document).ready(function() {

    /*script jQuery div id ou class avatar de rythmike enter and leave de la sourie*/
    $("#avatar").mouseenter(function() {
        $(".avatar").animate({
            width: "99px"
        }, 600);
    });
    $("#avatar").mouseleave(function() {
        $(".avatar").animate({
            width: "102px"
        }, 600);
    });
    
    $("#jQ-activate1").mouseenter(function() {
        $("#jQ-slide").fadeToggle(5000);
    });
    $("#jQ-activate1").mouseleave(function() {
        $("#jQ-slide").fadeToggle(14000);
    });
});



$(document).ready(function() {
//class="id-effect-jquery"

    /*script jQuery div id ou class avatar de rythmike enter and leave de la sourie*/
    $("#id-effect-jquery").mouseenter(function() {
        $(".id-effect-jquery").animate({
            width: "99px"
        }, 600);
    });
    $("#id-effect-jquery").mouseleave(function() {
        $(".avatar").animate({
            width: "102px"
        }, 600);
    });
    
});
    /*bien faire attention a fermer le script */

    
    
    
/*script jQuery div id ou class logoweb de rythmike baniere repetion de slide */
/*    $("#jQ-activate1").mouseover(function(){
        $("#jQ-slide").slideToggle(slow);
    });
    $("#jQ-activate1").click(function(){
      $(".jQ-slide").slideUp(3000);
    });

});

*/




    /*bien faire attention a fermer le script */


/*



$(document).ready(function(){
    $("#jQ-activate1").mouseenter(function() {
        $("#jQ-slide").hide()
        });
});


jQuery slideUp() Method

Example

Slide-up (hide) all <p> elements:
$("button").click(function(){
  $("p").slideUp();
});





    /*bien faire attention a fermer le script */








/*
$(document).ready(function () {
    $(".click").mouseenter(function () {
 /*       $(".clickOn").hide(1000);
        
        /*
        
        
        
        
        
            /*bien faire attention a fermer le script */
        
        
        /*
        $(".clickOn").animate({
        parametre de l'annimation jQ
            left: '35px',
            width: '145%',
            transform: rotate(45deg)
            /*entre des crochets
        }, 550);
    
    
    
    
    
    });
    $(".click").mouseleave(function () {
        $(".clickOn").animate({
            /*parametre de l'annimation jQ
            right: '25px',
            width: '100%'
            /*entre des crochets
        }, 250);
    });
});
    /*bien faire attention a fermer le script */


/*script "Accordion" en jQuery menu deroullant en CSS et JavaScript author : Thibaut Lemaire */
/*$(function () {
    var menubar
    var menubar = $('.accordion > ul').hide();
    
    menubar.first().show();
    $('.accordion > li > a').click(function() {
        var $this = $(this);
        menubar.slideUp();
        $this.parent().next().slideDown();
        return false;
    });
    
     Binding Events to the slides     click  IMG    class=""

});
*/
