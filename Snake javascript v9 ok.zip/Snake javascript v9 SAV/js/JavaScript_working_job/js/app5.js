
//author : Thibaut Lemaire
//doc name : app4.js
//date de création : 01/2019
//document type : JavaScript


/**** Rappel : https://www.youtube.com/watch?v=PkZNo7MFNFg&t=2764s
myArray.pop() myArray.push() 
*/








//manipulate array with shift remove the first element ARRAY
/*
var ourArray = ["simpson", "J", ["cat"]];
var removeFromArray = ourArray.shift();
console.log(ourArray);


var myArray = [["john", 23], ["dog", 3]];
console.log(myArray [0]);
var removeFromMyAray = myArray.shift();
console.log(myArray[0]);
*/







//shift unshift array tableau

/*
var ourArray = ["simpson", "J", ["cat"]];
ourArray.shift();
ourArray.unshift("Happy");// add elelent to the begin of the array push at the end of the array

var myArray = [["John", 23], ["dogs", 2]];
myArray.shift();//enleve un element au debut du tableau
myArray.unshift(["Paul", 35]);
myArray.push(["Ray", 45]);// ok a la fin du tableau ok
myArray.unshift(["Mike", 22]);//ok debut du tableau
console.log(myArray);
*/





//Shopping List exemple ARRAY
/*
var myList = [["cereal",3], ["milk",2],["bananas",3]["juce",2],["eggs",12]];
*/
//Function function function fuction JS
/*
function ourReusableFunction() {
    console.log("Heyya, world");
}
ourReusableFunction();
ourReusableFunction();
ourReusableFunction();

function reusableFunction() {
    console.log("hi world");
}
reusableFunction();
*/





//function with args calcul de function avec parametre 
//author : T.L. contact@rythmike.com
/*
function ourFunctionWithArgs(a, b){
    console.log(a - b);
}
ourFunctionWithArgs(10, 5);
ourFunctionWithArgs(10, 2.4);//com it's ok 10-2.4= 7.6 parceque 2.4GHZ

function ourFunctionWithArgs2(a, b){
    console.log(a * b);
}
ourFunctionWithArgs2(10, 5);
ourFunctionWithArgs2(11, 2.4);//test calcul
*/










/*****special a retenir a revenir dessus plus tard 
//global scope and function


var myGlobal = 10; // is defined 

function fun1() {
    // assign 5 to oppsGlobal Here
    oopsGlobal = 5;  // isd defined into the function  
    
}

// only change the code above this line 
function fun2(){
    var output = ""; 
    if (typeof myGlobal != "undefined"){
        output += "my global : " + myGlobal;
    }
    if (typeof oopsGlobal != "undefined"){
        output += " oppsGlobal : " + oopsGlobal;
    }
    console.log(output);
}
fun1();
fun2();

***/







//local scope and function local 
/*
function myLocalScope() {
    var myVar = 5;
    console.log(myVar);
    
}
myLocalScope();

console.log(myVar); //dont work becose myVar is outside of the command
****/








//Global vs. Local scope Function with the same name 
/*
var outerWear = "T-shirt"; 


function myOutfit() {
    var outerWear = "Sweat-shirt Yellow";
    return outerWear;
}
console.log(myOutfit());
console.log(outerWear);


com dans une function la porter de la variable est local 
ce qui fait que quand on appel la variable outerWear en dehors de la function la variable est toujours T-shirt
*/
 


//Return a Value from a Function with Return
/***
function minusSeven(num) {
    return num - 7;
}
console.log(minusSeven(10));   // 10 -7  = 3


function timesFive(num) {
    return num * 5;
}
console.log(timesFive(5));
***/






//Understanding Undefined Value Returnned from a Function 
// a revoir fix probleme undefined
// la variable n'a pas une porter global elle n'ai pas dans la function 
/****
var sum = 0;

function addThree() {
    sum = sum + 3;
}

function addFive() {
    sum += 5;
}

function addTenWithReturn() {
    sum += 10;
    return sum;
}
console.log(sum);

console.log(addThree());
console.log(addFive());
console.log(addTenWithReturn());


//UNDIFINED good job HelloWorld
***/






//
var changed = 0;
function change(num) {
    return (num + 5) / 3;
}
//console.log(change(10));

changed = change(10);
console.log(changed);

var processed = 0;
function processArg(num) {
    return (num + 3) / 5;
}
processed = processArg(7);
console.log(processed);







//









//

