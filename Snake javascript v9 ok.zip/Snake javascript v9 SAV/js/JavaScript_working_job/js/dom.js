//EXAMINE THE DOCUMENT OBJECT//
//console.dir(document);
//console.log(document.domain);
//console.log(document.URL);
//console.log(document.title);//affiche les DOM selectionné
//document.title = 123;  //CHANGER LE CONTENU DU DOM //
//console.log(document.doctype);
//console.log(document.head);
//console.log(document.body);
//console.dir(document);
//console.log(document.all);
//console.log(document.span);
//console.log(document.all);
//console.log(document.links);
//console.log(document.images);

//GET ELEMENNT BY ID
//console.log(document.getElementById('header-title'));
var headerTitle = document.getElementById('header-title');
console.log(headerTitle);
//POUR ALLER AU N QUI COMMENCE PAR 0 DES DOM LINKS//
//console.log(document.links[1]);
//headerTitle.textContent = "Bonjour";
//console.log(headerTitle);



/***
document.getElementById()
document.getElementsByClassName()
document.getElementsByTagName()
document.querySelector()
document.querySelectorAll()
***/
