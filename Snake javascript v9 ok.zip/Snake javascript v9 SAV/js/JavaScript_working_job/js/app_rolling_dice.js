// author : Thibaut Lemaire
// date : 02/02/2019



//
    //<![CDATA[
    //from stringMethods.html
    diceRoll = function () {
        var die = Math.ceil(Math.random() * 6);
        alert("lancer de dé " + die);
        if (die == 2) {
          alert("you WIN !! c'est un deux");
  
        } else {
          alert(" perdu " + "c'est un " + die);
        }
      }
      diceRoll();










