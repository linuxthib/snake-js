
//author : Thibaut Lemaire
//doc name : app4.js
//date de création : 01/2019
//document type : JavaScript


/**** Rappel : https://www.youtube.com/watch?v=PkZNo7MFNFg&t=2764s

CODE OUTPUT
\'  single quote
\"  double quote
\\  backslash
\n  newline
\r  carriage return ( ?)
\t  tab
\b  backspace
\f  form feed (formaulaire)

****/

//ad to the variable 
/*
var ourStr = "I come first.";
var myStr = " my name is Beau"
ourStr += " I come after";
console.log(ourStr);
ourStr += " pOur ajouter du texte avec += concanater";
console.log (ourStr);
*/




//+= ajout dans une string
/*
var anAdjective = "awesome ! ";
var ourStr = "Rythmike is ";
ourStr += anAdjective;
console.log (ourStr);
*/  





//find length of string    length = longeur
/*
var lastNameLength = 0;//init
var lastName = "Lovelace";

lastNameLength = lastName.length;
console.log (lastNameLength);
*/    





//Bracket notation to find fisrt character in string
//start zero!
/*
var fisrtLetterOfTheLastName = ""; //init
var lastName = "Lovelace";

fisrtLetterOfTheLastName = lastName [0];
console.log (fisrtLetterOfTheLastName); //ok L MAJ
*/







//String Immutability change CHAR on a string
/*
var myStr = "Jello World";

myStr[3] = "h"; //fix probleme this does not work
console.log(myStr)
myStr = "Hello World";
console.log (myStr);
*/







//Bracket notation to find the last letter Character in String
/*
var firstName = "Ada";
var lastLetterOfFirstName = firstName[firstName.length - 1];

console.log(lastLetterOfFirstName);

*/





//word blanks world = monde  word = mot
//IMPORTANT section ok Rappel function
/*
function wordBlanks(myNoun, myAdjective, myVerb, myAdverb) {
    //your code below this line
    var result = ""; //init var 
    result += "The " + myAdjective + " " + myNoun + " " + myVerb + " to the store " + myAdverb;
    //your code below this line
    return result;
};
console.log(wordBlanks("dogs", "bigs", "ran", "quickly"));
console.log (wordBlanks("bike", "slow", "flew", "slowly"));

*/




//Store Multiple Values with Arrays fabriquer un tableau
/*
var myArray = ["Quincy", 1];
*/




//tableau dans le tableau 
/*
var myArrray [["the universe", 42], [everything,101010]];

*/





//chercher des données des un Array first element
/*
var ourArray = [50,60,70];
var ourData = ourArray [0];

console.log(ourData); // that's ok 50 fifty zero 
*/





//pas possible de modifier des data dans les string cf haut mais dans un array on peut IMPORTANT change data in a array
/*
var ourArray = [18, 64, 99];
ourArray[1] = 45;

console.log(ourArray[1]);

var myArray = [18, 64, 99];
myArray[0] = 45;

console.log(myArray);
*/





//Acccess multi-Dimentional Array with indexes 3 layers deep Array
/*
var myArray = [[1,2,3], [4,5,6], [7,8,9], [[10,11,12], 13, 14]]; 

var myData = myArray[2][0]; //chercher un nombre en multi lol 
console.log(myData);

*/




//Manipulate Array with .push() that push element at the end of the array 
/*
var ourArray = ["Stimpson", "J", "cat"];
ourArray.push(["Happy", "joy"]);
//ourArray now equals ["simpson, "J", "cat", ["happy", "joy"]]

var myArray = [["John", 23], ["cat", 2]];

myArray.push([40, "ans", "bientot", 42]);
console.log(myArray);
*/



//manipulate arrays with .pop() we can remove a elemnt in a array 
/*
var ourArray = [1,2,3];
var removeFromOurArray = ourArray.pop(); //remove the last element from the array
console.log(ourArray);


var myArray = [["john", 23], ["cat", 2]];//setup

var removedFromMyArray = myArray.pop();
console.log(myArray);

//commentaire dans la varialble removeFromThe array il y a les ellement qui sont supprimer du tableau , penser a bien rappeller la bonne variable intitiale lol
console.log(removedFromMyArray);//attention c'est ce qu'on veut effacer debrouille toi
*/
