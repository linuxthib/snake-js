var number = 5; //in-line comment commentaires javascript 

/*multi-line comment with this code 

o 

o

o

close mult-line comment
*/
number = 9;
/*data type in javascript :  number undefined null symbol object string boolean

*/

/*
var myName = "Thibaut";
myName = 8;
let ourName = "freeCodeCamp";
const pi = 3.14;

/*never change you could never change if you want to change there an error ``

*/
/*
var a;
var b = 2;
console.log(a);//affiche undefined car pas de valeur dans la variable a donc ca 
console.log(b);
a = 7;
console.log(b);
b = a;
console.log(a);// a et b pareil 7 je met a dans b */


//initialise three variable
/*
var a = 5;
var b = 10;
var c = "I am a ";
console.log(c);
*/
// code suite 
/*
a = a + 1;
b = b + 5;
c = c + "string";
console.log(a);
console.log(b);
console.log(c);
*/


//javascript est sensible a la casse
var studlyCapVar;
var properCamelCase;
var titleCaseOver;// a traduire en fancais 
/*
studlyCapVar = 10;
properCamelCase = "a string";
titleCaseOver = 9000;// a traduire en fancais 
var myVar = 87;
console.log(myVar);
myVar++; //incremente de 1 en plus a la variable . 
console.log(myVar);
myVar++;
console.log(myVar);
myVar++;
console.log(myVar);
console.log(properCamelCase);
*/

//les opérations en javascript
var sum = 10 + 10;
console.log(sum)
var difference = 45 - 30;
console.log(difference)
var product = 7 * 7;
console.log(product)
var quotient = 12/7;
console.log(quotient)