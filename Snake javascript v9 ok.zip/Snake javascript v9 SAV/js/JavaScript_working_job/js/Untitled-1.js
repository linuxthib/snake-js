//author : Thibaut Lemaire
//Name : Créer un snake
//date : Janvier 2022
alert('alert');
drawSnake([
    [0, 0],
    [0, 1],
    [0, 2],
    [0, 3],
    [0, 4]
])

function drawSnake() {

}