var a ='hello Word';

function b() {
    console.log('called b!');
}
console.log(a);
b();