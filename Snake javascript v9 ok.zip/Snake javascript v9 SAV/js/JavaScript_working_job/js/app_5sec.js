// author : Thibaut Lemaire
// date : 02/02/2019


window.addEventListener('load', init);


//Globals
let time = 5;
let score = 0;
let isPlaying;

//availlable level

//DOM Elements
const wordInput = document.querySelector("#word-input");//
const currentWord = document.querySelector("#current-word");//
const scoreDisplay = document.querySelector("#score");//not ok
const timeDisplay = document.querySelector("#time");//ok
const message = document.querySelector("#message");//OK
const seconds = document.querySelector("#seconds");//OK

//current code array

const words = ['chapeau','rivere' ,'tache', 'guère', 'hauteur', 'troubler', 'tendre', 'beau', 'curiosité', 'répandre', 'glace','résister', 'froid', 'prison', 'étage', 'billet', 'droit', 'sérieux','protéger', 'pauvre', 'rose', 'enfermer','attitude', 'dur', 'mode', 'neuf', 'crainte', 'creuser', 'grandir', 'enfoncer', 'vêtement', 'envelopper', 'vague', 'prévenir', 'violence', 'inspirer', 'inutile', 'content', 'courant', 'folie', 'pitié', 'intention', 'ramasser', 'endormir', 'inventer', 'trace', 'toile', 'confier', 'croiser', 'entretenir', 'rouge', 'professeur', 'surveiller', 'visible', 'perdu','réserver', 'bas', 'lien', 'queue', 'bande', 'confondre', 'grain', 'mensonge', 'dégage', 'probablement', 'illusion', 'incapable', 'parer', 'épreuve', 'immédiatement', 'attente', 'visiter', 'instrument', 'évidemment', 'auparavant',
'détourner', 'explication', 'régulier', 'reproche', 'souci', 'plier', 'extrême', 'accueillir', 'juif', 'leçon', 'redevenir', 'approuve', 'parfait','emparer', 'aborder', 'heurter', 'tel', 'noyer', 'semer', 'ferme', 'manche', 'rage', 'gré', 'guider', 'piquer', 'meilleur'];

//Initialize Game
function init() {
    //load word from array
    showWord(words);
	
    //start matching on word input
    wordInput.addEventListener('input', startMatch);
    //Call count down seconde
    setInterval(countdown, 1000);
    //check the game status
    setInterval(checkStatus, 50);
}

//start match 
function startMatch() {
    if (matchWords()) {
        isPlaying = true;
        time = 6;
        showWord(words);
        wordInput.value = '';
        score++;
    }
	// if negative score -1 display 0
	if(score === -1) {
	   	scoreDisplay.innerHTML = 0;
	   } else {
    	scoreDisplay.innerHTML = score;
	   }
}
function matchWords() {
        if(wordInput.value === currentWord.innerHTML) {
            message.innerHTML = 'correct ! ';
            return true;
        } else {
            message.innerHTML = '';
            return false;
        }
    }


//pick & show random word
function showWord(words) {
    //genarate ramdom array index
    const randIndex = Math.floor(Math.random() * words.length);
    //output a random word
    currentWord.innerHTML = words[randIndex];
    
}    
//countdown timer 
function countdown() {
    // make sure time is runout
    if(time > 0) {
        //decrement
        time--;
    }
    else if(time === 0) {
        //game is over
        isPlaying = false;
    }
    //show time
    timeDisplay.innerHTML = time;
}

// check game status
function checkStatus() {
    if(!isPlaying && time === 0) {
        message.innerHTML ='Game is Over!!';
        score = -1;
    }
}

console.log(score);









// + de mots aléatoire
























//































//


















//
    
    /*effacer	(verbe)
973	reculer	(verbe)
973	user	(verbe)
972	blanc	(subst.)
971	nourrir	(verbe)
970	dangereux	(adj.)
967	poésie	(subst.)
962	sommet	(subst.)
961	remplacer	(verbe)
960	souhaiter	(verbe)
956	avance	(subst.)
955	autorité	(subst.)
954	épais	(adj.)
953	inquiétude	(subst.)
952	choix	(subst.)
951	tombe	(subst.)
950	marchand	(subst.)
949	nombreux	(adj.)
948	muet	(adj.)
947	signer	(verbe)
946	absolument	(adv.)
944	cercle	(subst.)
944	interroger	(verbe)
942	dominer	(verbe)
940	défaut	(subst.)
938	enfance	(subst.)
937	faveur	(subst.)
937	réel	(adj.)
934	commander	(verbe)
934	supposer	(verbe)
933	dépasser	(verbe)
930	sourd	(adj.)
929	cruel	(adj.)
928	dimanche	(subst.)
928	erreur	(subst.)
927	cerveau	(subst.)
926	accuser	(verbe)
924	arrivée	(subst.)
924	rapidement	(adv.)
922	vol	(subst.)
921	habiller	(verbe)
920	condamner	(verbe)
918	lors	(adv.)
918	menacer	(verbe)
918	seuil	(subst.)
916	écraser	(verbe)
915	perte	(subst.)
914	troisième	(adj.)
913	chance	(subst.)
906	vieil	(adj.)
905	même	(pron.)
902	céder	(verbe)
901	douceur	(subst.)
901	droite	(adj.)
900	vide	(subst.)
899	autrement	(adv.)
899	drôle	(adj.)
899	ruine	(subst.)
898	écarter	(verbe)
898	rang	(subst.)
897	réclamer	(verbe)
896	chiffre	(subst.)
892	voisin	(adj.)
890	militaire	(adj.)
884	roche	(subst.)
883	distance	(subst.)
882	apparence	(subst.)
881	dessiner	(verbe)
877	conclure	(verbe)
877	françois	(subst.)
877	lier	(verbe)
876	discussion	(subst)
873	admettre	(verbe)
873	banc	(subst.)
873	terreur	(subst.)
872	attaquer	(verbe)
872	vers	(subst.)
871	respecter	(verbe)
869	rose	(adj.)
869	silencieux	(adj.)
868	anglais	(adj.)
868	course	(subst.)
865	portier	(subst.)
861	chat	(subst.)
860	pendre	(verbe)
859	supporter	(verbe)
856	tempête	(subst.)
855	parfaitement	(adv)
855	paysage	(subst.)
855	quart	(subst.)
853	figurer	(verbe)
851	profiter	(verbe)
847	accrocher	(verbe)
843	calmer	(verbe)
843	satisfaire	(verbe)
842	public	(subst.)
838	race	(subst.)
838	valoir	(verbe)
837	barbe	(subst.)
836	signifier	(verbe)
835	couche	(subst.)
834	inquiéter	(verbe)
833	colon	(subst.)
833	désormais	(adv.)
831	fidèle	(adj.)
829	assister	(verbe)
829	rideau	(subst.)
828	inviter	(verbe)
827	déchirer	(verbe)
824	fatigue	(subst.)
824	risquer	(verbe)
823	règle	(subst.)
822	gauche	(adj.)
822	parcourir	(verbe)
822	présent	(adj.)
821	rejeter	(verbe)
820	naissance	(subst.)
818	loup	(subst.)
816	renoncer	(verbe)
815	complètement	(adv)
814	extraordinaire	(adj.)
810	veiller	(verbe)
806	transformer	(verb)
805	tracer	(verbe)
804	chute	(subst.)
803	divers	(adj.)
802	résistance	(subst)
801	contenter	(verbe)
800	chemise	(subst.)
800	mince	(adj.)
800	naturellement	(adv.)
799	siège	(subst.)
797	as	(subst.)
797	patron	(subst.)
796	calme	(subst.)
795	mériter	(verbe)
795	printemps	(subst.)
793	angoisse	(subst.)
791	précipiter	(verbe)
791	rompre	(verbe)
788	habitant	(subst.)
788	plein	(prép.)
784	caresser	(verbe)
784	métier	(subst.)
783	étouffer	(verbe)
782	animer	(verbe)
782	note	(subst.)
781	passé	(adj.)
779	fine	(adj.)
779	fixe	(adj.)
778	casser	(verbe)
777	fusil	(subst.)
774	rond	(adj.)
771	agent	(subst.)
763	fonder	(verbe)
760	roman	(subst.)
759	franchir	(verbe)
759	plante	(subst.)
754	abattre	(verbe)
754	discuter	(verbe)
748	fatiguer	(verbe)
746	humide	(adj.)
746	réflexion	(subst.)
745	consentir	(verbe)
740	accent	(subst.)
738	curieux	(adj.)
735	repas	(subst.)
731	étendue	(subst.)
731	regretter	(verbe)
730	joindre	(verbe)
730	profondément	(adv)
729	secours	(subst.)
728	commencement	(subst.)
724	corde	(subst.)
720	secrétaire	(subst)
720	vaincre	(verbe)
718	saison	(subst.)
715	précieux	(adj.)
714	précis	(adj.)
712	consulter	(verbe)
709	haïr	(verbe)
701	repousser	(verbe)
700	paupière	(subst.)
696	certainement	(adv)
695	tapis	(subst.)
694	noire	(adj.)
691	chasse	(subst.)
690	exécuter	(verbe)
690	nerveux	(adj.)
690	nul	(dét.)
689	commun	(adj.)
689	exposer	(verbe)
686	clef	(subst.)
684	claire	(adj.)
683	voyager	(verbe)
680	haute	(adj.)
680	renverser	(verbe)
677	sueur	(subst.)
676	âgé	(adj.)
675	ferme	(subst.)
675	rassurer	(verbe)
674	retomber	(verbe)
672	décrire	(verbe)
670	mentir	(verbe)
669	instinct	(subst.)
667	armer	(verbe)
667	paquet	(subst.)
666	drame	(subst.)
664	absolu	(adj.)
661	savoir	(subst.)
660	mine	(subst.)
660	vision	(subst.)
659	étaler	(verbe)
658	sentier	(subst.)
657	demain	(subst.)
655	beau	(adv.)
652	blond	(adj.)
651	essuyer	(verbe)
650	planche	(subst.)
650	précéder	(verbe)
649	dehors	(subst.)
647	salut	(subst.)
646	tâche	(subst.)
644	désigner	(verbe)
643	fin	(adj.)
642	abri	(subst.)
641	détacher	(verbe)
638	recueillir	(verbe)
636	rencontre	(subst.)
***/
