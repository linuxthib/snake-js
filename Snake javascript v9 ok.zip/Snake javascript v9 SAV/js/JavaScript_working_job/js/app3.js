/*var product;

product = 30*30;
console.log(product);

*/

//rappel camelCase, difference 
// increment number :    myVar++     myVar--

// multiplicate decimal number 
/*
var product = 2.0 * 2.5;    // egal 5
console.log(product);
//divide decimals

var quotient = 4.4 / 2.0;  // egal 2.2
console.log(quotient);

// remainder
var remainder;
remainder = 11 % 3; //modulo reste de 9 /3 egal a 11-9 = 2
console.log(remainder);


//compound Assignement with augmented Addition

var a = 3;
var b = 17;
var c = 12;

// only modify cade below this line 

a += 12; // egale a     a = a + 12; 
b += 9;
c += 7; 
    
console.log(a);   // dois etre egal a 15 
    
//revoir le modulo reste de la division remainder en anglais
    
//meme chose pour -=
//compound Assignement with augmented Soustraction

var a = 11;
var b = 9;
var c = 3;

// only modify cade below this line 

a -= 6; 
b -= 15;  // chiffre negatif
c -= 1;
console.log(b)
  COMMENTAIRE javascript © Thibaut L. */  

/*    
//compound Assignement with augmented Multiplication
var a = 5;
var b = 12;
var c = 4.6;

// only modify cade below this line 

a *= 5; 
b *= 3;  // chiffre negatif
c *= 10;
console.log(a)
console.log(b) // egale a 3*12  donc 36       work hard this is JavaScript

*/
//compound Assignement with augmented Division


var a = 48;
var b = 108;
var c = 33;

// only modify cade below this line 

a /= 12; 
b /= 4;
c /= 11; 
console.log(a);
console.log(b);
console.log(c);
/*
//declare string variable

var firstName = "Alan";   // prenom en Francais 
var lastName = "Turing";


var myFirstName = "Beau";
var myLastName = "Carne";
*/
/*
// antislash  gh   quote double quote

var myStr = "I am a \"double quoted\" string inside quote \"pour afficher des guillemet dans Javascript\" !! ";
console.log(myStr);

*/


var myStr = '<a href=\"http://www.myexample.com\" target=\"_blank\">Link</a>    c\'est la meme chose que '
console.log(myStr)
// egale 

var myStr = '<a href="http://www.myexample.com" target="_blank">Link</a>' 
console.log(myStr)
// avec le quote ' on peut suprimmer les antislash simple quote  ok










//







    
    
    
    
    
//
    
    
    
    
    
    
    
//
    
    